package com.radubulai.springbootapisecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootapisecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootapisecurityApplication.class, args);
	}

}
