package com.radubulai.springbootapisecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootapisecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
